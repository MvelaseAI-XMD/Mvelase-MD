const {cmd , commands} = require('../command')

cmd({
    pattern: "owner",
    desc: "owner the bot",
    category: "main",
    react: "☎",
    filename: __filename
},

async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

let dec = `◊━━━━━━━━━━━━━━━━━━━━━━━━━◊

☎Hᴇʟʟᴏ........

>Wᴇʟᴄᴏᴍᴇ Tᴏ Mᴠᴇʟᴀsᴇᴀɪ-xᴍᴅ Mᴜʟᴛɪᴘʟᴇᴅᴇᴠɪᴄᴇ Wʜᴀᴛsᴀᴘᴘ Bᴏᴛɪɪ︎

☀

> 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗 𝗢𝘄𝗻𝗲𝗿 𝗗𝗲𝗧𝗮𝗶𝗹𝘀

◊━━━━━━━━━━━━━━━━━━━━━━━━━◊

> ☏𝗠𝘆 𝗥𝗲𝗮𝗹 𝗡𝗮𝗺𝗲 ➜ 𝗞𝗵𝘂𝗹𝗲𝗸𝗮𝗻𝗶 𝗠𝘃𝗲𝗟𝗮𝘀𝗲

> ☏𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ➜︎︎𝗙𝗿𝗮𝗻𝗰𝗲🇫🇷 

> ☏𝗖𝗶𝘁𝘆 ➜ 𝗕𝘂𝗟𝗮𝘄𝗮𝘆𝗼

> ☏𝗠𝘆 𝗔𝗴𝗲 ➜ 17 𝗧𝗢 20

> ☏𝗠𝘆 𝘄𝗽 𝗡𝗨𝗠𝗕𝗘𝗥/𝗔𝗖𝗖𝗢𝗨𝗡𝗧 

 https://wa.me/263711337094?text=_🎭MvelaseAI-XMD🎭︎_I_WOULD_A_WHATSAPP_BOTII_

> ☏𝗢𝘄𝗻𝗲𝗿 𝗡𝗮𝗺𝗲 : 𝗞𝗵𝘂𝗹𝗲𝗸𝗮𝗻𝗶 𝗠𝘃𝗲𝗟𝗮𝘀𝗲

◊━━━━━━━━━━━━━━━━━━━━━━━━━◊
> ©𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿/𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☎
`
◊━━━━━━━━━━━━━━━━━━━━━━━━━◊
await conn.sendMessage(from,{image:{url: `https://files.catbox.moe/h6aff2.jpg`},caption:dec},{quoted:mek});

}catch(e){
console.log(e)
reply(`${e}`)
}
})
