const {cmd , commands} = require('../command')

cmd({
    pattern: "menu",
    desc: "menu the bot",
    category: "menu",
    react: "☎ ",
    filename: __filename
},

async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

let dec = `
╭─────────────────────────━┈⊷
│*☎‍𝗕𝗢𝗧𝗜𝗜 𝗡𝗮𝗺𝗲*: 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☉
│*☎☭𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿*: 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☉    
│*👤 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 𝗔𝗰𝗰𝗼𝘂𝗻𝗧𝗜𝗜*: 263711337094
│
│*☏𝗩𝗲𝗿𝘀𝗶𝗼𝗻*: 1.0.0
│*💻 𝗛𝗢𝗦𝗧* :  fv-az661-842
│*💫 𝗣𝗥𝗘𝗙𝗜𝗫:* .
╰───────────━┈⊷ 

╭━━━❮ 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗 ❯━━━◊
┃◆ .𝗔𝗜✰
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━◊
╭━━━❮  ☎𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 ❯━━━━◊
┃◆ .𝗺𝗲𝗻𝘂 ✔
┃◆ .𝗼𝘄𝗻𝗲𝗿 ☎
┃◆ .𝗿𝗲𝘀𝘁𝗮𝗿𝘁 ✔
┃◆ .𝗽𝗶𝗻𝗴 ☎
┃◆ .𝘃𝗶𝗱𝗲𝗼 ✔
┃◆ .𝗽𝗹𝗮𝘆 ☎
┃◆ .𝗺𝘃𝗲𝗹𝗮𝘀𝗲𝗮𝗶 ✔
┃◆ .𝗳𝗮𝗰𝘁 ☎
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━◊


 > ©𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿/𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☎
`
await conn.sendMessage(from,{image:{url: `https://files.catbox.moe/h6aff2.jpg`},caption:dec},{quoted:mek});

}catch(e){
console.log(e)
reply(`${e}`)
}
})
