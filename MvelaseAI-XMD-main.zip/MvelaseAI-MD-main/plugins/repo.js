const {cmd , commands} = require('../command')

cmd({
    pattern: "repo",
    desc: "repo the bot",
    category: "main",
    react: "❣",
    filename: __filename
},

async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

let dec = `*💌 𝗛𝗘𝗟𝗟𝗢 ${pushname}*
          
☎➜𝗥𝗘𝗣𝗢 𝗟𝗜𝗡𝗞✅

⚡◦ https://github.com/kingmalvn/MvelaseAI-XMD V2

☎➜𝗬𝗢𝗨𝗧𝗨𝗕𝗘 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗣𝗟𝗨𝗚✅

⚡◦ https://youtube.com/@mvelaseai-xmd?si=hT4DetYyEI_mE-gq

☎➜𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝗣𝗟𝗨𝗚✅

⚡◦ https://whatsapp.com/channel/0029VajdbH511ulTyGysZq17


☎➜𝗧𝗘𝗖𝗛𝗚𝗨𝗬➜𝗛𝗔𝗖𝗞𝗘𝗥➜☎

◊━━━━━━━━━━━━━━━━━━━━━━━━━◊

> *©𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿/𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☎*
`
◊━━━━━━━━━━━━━━━━━━━━━━━━━◊

await conn.sendMessage(from,{image:{url: `https://files.catbox.moe/n5vvij.jpg`},caption:dec},{quoted:mek});

}catch(e){
console.log(e)
reply(`${e}`)
}
})
