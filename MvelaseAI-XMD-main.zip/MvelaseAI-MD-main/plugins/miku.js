const config = require('../config')
const {cmd , commands} = require('../command')

cmd({
    pattern: "𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗",
    desc: "Check bot online or no.",
    category: "main",
    react: "☎",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

let des = `☕ 𝗛𝗘𝗟𝗟𝗢 ${pushname} 🇱 🇲  🇦 🇱 🇮 🇻 🇪  🇳 🇴 🇼 ✅

*𝗔 𝗪𝗵𝗮𝗧𝘀𝗮𝗽𝗽 𝗯𝗼𝗧𝗜𝗜 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗 ☎*

| *𝗕𝗢𝗧𝗜𝗜 𝗩𝗲𝗿𝘀𝗶𝗼𝗻*: 1.0.0
| *𝗠𝗲𝗺𝗼𝗿𝘆*: 38.09MB/7930MB
| *𝗕𝗢𝗧𝗜𝗜 𝗢𝗪𝗡𝗘𝗥*: 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗

𝙇 𝙈𝙫𝙚𝙇𝙖𝙨𝙚𝘼𝙄-𝙓𝙈𝘿 𝙒𝙝𝙖𝙏𝙨𝙖𝙥𝙥 𝘽𝙊𝙏𝙄𝙄. How can I help you❣️.
To get the menu, type as .menu . If you need to know something about MvelaseAI-XMD BOTII💌,
type as owner and direct the question to me. Good day❣️.

*°᭄🇫🇷 𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗*

 > ©𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿/𝗠𝘃𝗲𝗹𝗮𝘀𝗲𝗔𝗜-𝗫𝗠𝗗☎`
return await conn.sendMessage(from,{image: {url: config.ALIVE_IMG},caption: des},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})
